MISORA EDITOR — PHASE 2
ENGINEERING TASK: S0 + S1 (PRE-FLIGHT & STAGED OPEN FILE SAFETY)

ROLE & MODE:
You are a senior Python engineer working on Misora Editor, a Tkinter-based Unity3D story editing application. Execute this narrowly scoped data-integrity task with minimal, clean diffs. If operating in Plan Mode: S0 hygiene edits below are pre-authorized; present a brief plan and wait for approval before modifying misora.py source (S1).

CONTEXT POINTERS (READ BEFORE EDITING):
- AGENTS.md
- PROJECT_STATE.md
- docs/COPILOT_WORKFLOW.md
- misora.py (specifically MisoraApp.open_file() and its helpers)
- Relevant existing tests under tests/
Do not rely on chat summaries as source code; verify exact lines directly from disk.

==================================================
PART 0 — NON-NEGOTIABLE GUARDRAILS & FILE OWNERSHIP
==================================================
1. Workspace: work strictly in the existing local Windows workspace `D:\Misora-Editor`.
2. Allowed files to create/modify for this task:
   - `.gitattributes`
   - `PROJECT_STATE.md`
   - `misora.py` (scoped to `open_file()` and tightly related helper logic)
   - `tests/test_s1_open_file_safety.py` (new focused regression test file)
3. DO NOT modify:
   - `core/story_ast.py`, `core/bundle_io.py`, `core/undo_journal.py`, or ANY other `core/` module
   - Unrelated UI views, shortcuts, MTL, search, or Replace-All code
   Runtime mocking of core callables inside tests is allowed; editing core source is NOT.
4. Preserve all existing user files and uncommitted work. Never run `git reset`, `git clean`, or destructive `git checkout`.
5. Do not create a git commit or push changes.
6. Do not add new dependencies.
7. Do not remove, skip, weaken, or silently mock existing tests to force a pass.
8. Never claim a command or test passed unless you actually executed it and observed the output.
9. Follow all `AGENTS.md` architectural invariants and the repository workflow in `docs/COPILOT_WORKFLOW.md`.
10. Stop strictly after S0 and S1. Do not implement S2 or any later slice.

PRE-EXISTING PROMPT-PACK SETUP FILES (READ-ONLY):
Before this task starts, the user may have installed these approved workflow files into the checkout:
- `.github/github-app.yml`
- `docs/COPILOT_WORKFLOW.md`
- `docs/copilot-prompts/PHASE2_S0_S1.md`
- `START_HERE.txt` (if present at repository root)
These setup files are intentional, user-authorized inputs. If they appear as untracked files in the initial `git status`, list them separately as pre-existing setup files; do NOT treat them as unexpected source changes or stop solely because of them. Treat them as read-only and do not modify them during S0/S1. Any other unexplained local changes must still be reported and trigger the applicable stop condition.

==================================================
S0 — BASELINE VERIFICATION & REPOSITORY HYGIENE
==================================================
Complete and record S0 BEFORE modifying `misora.py`.

A. Verify workspace state and report:
   - Git repository root (expected: `D:\Misora-Editor`)
   - Current branch and HEAD commit hash
   - `git status` (any uncommitted modifications)
   - Exact Python interpreter path and version

B. Verify the `misora.py` PRE-EDIT baseline. Known-good reference values:
   - Windows CRLF form: 510,461 bytes,
     SHA-256 `2188eab968e031d4d5469f117f3cfb8403dc27622b5b6009d38b3880dd97babe`
   - LF-normalized form of the same content: 499,293 bytes
   Compute the raw-byte SHA-256 and the LF-normalized byte count, and confirm the file matches this baseline in either line-ending representation. These reference values apply ONLY to the pre-edit file; do not re-apply them after S1 changes the file.
   If unexpected SEMANTIC modifications are present, STOP before editing source and report them without overwriting anything.

C. Verify runtime config tracking:
   - Check whether `misora_config.json` is tracked by Git (`.gitignore` already excludes it).
   - Never print config contents, API keys, or secrets.
   - If tracked, report it without deleting or automatically untracking it.

D. Add minimal `.gitattributes` with exactly:
```
*.py text
*.bat text eol=crlf
*.unity3d binary
*.asset binary
```
   IMPORTANT:
   - Do NOT force `*.py` to `eol=lf`.
   - Do NOT run `git add --renormalize .` or perform mass line-ending conversions.
   - After writing it, confirm `git status` shows no mass file modification; if it does, STOP and report.

E. Resolve `PROJECT_STATE.md` Git conflict markers:
   - Remove unresolved markers (`<<<<<<<`, `=======`, `>>>>>>>`) while preserving valid historical information.
   - Do not invent version numbers or unverified test counts.

F. Run baseline checks. Prefer `py -3.12`; if the `py` launcher is unavailable, fall back to the active Python 3.12 interpreter. Report the exact command used.
   - `py -3.12 -m compileall -q misora.py core assets tests`
   - `py -3.12 -m unittest discover -s tests -v`
   Record actual total tests, passed, failures, errors, skipped, OS, Python version, and any missing dependencies/fixtures. Do not claim the historical 100/100 count unless this run confirms it. If the full suite cannot complete for environment reasons (missing UnityPy, missing fixture, no display), report that as an environment blocker honestly and STILL run the focused S1 tests below after creating them.

==================================================
S1 — STAGED OPEN FILE SAFETY (OPEN-FAILURE-STATE-CORRUPTION)
==================================================
TARGET: `misora.py` -> `MisoraApp.open_file()`

ROOT PROBLEM TO FIX:
1. `open_file()` mutates active application state (`current_file_path`, `is_dirty`, `_modified_boxes`, `_original_box_texts`, `_locked_boxes`, `_plain_text_content`, window title, `recent_files`, `last_opened_dir`, etc.) BEFORE the target file finishes loading and parsing. If loading fails, old document/Unity objects remain paired with the failed file's path and wiped metadata/locks.
2. Non-bundle files are read with `encoding="utf-8", errors="replace"`, silently corrupting invalid UTF-8 bytes into `U+FFFD` as a successful load.

REQUIRED IMPLEMENTATION:

A. Stage Loading & Strict Decoding in Local Variables
   - Load, decode, and parse the target file into local temporary variables without mutating any `self.*` document/UI state beforehand.
   - Reuse existing loaders strictly:
     1. Unity bundles (`.unity3d`, `.asset`): reuse `load_bundle_story()`.
     2. Misora v2 scripts: reuse `StoryDocument.from_v2_text()`.
     3. Ordinary plain-text files: strict UTF-8 decoding (`encoding="utf-8"`, NO `errors="replace"`, NO `errors="ignore"`).
   - Invalid UTF-8 (`UnicodeDecodeError`), malformed v2 parse errors, and corrupt bundle errors MUST all fail cleanly.

B. Pending Edit Flush on Valid Switch (`AGENTS.md` Rule 13)
   - A previous context exists when `self.current_file_path is not None` (this covers story documents AND plain-text files where `current_doc is None`). On the very first open, or when no previous context exists, skip the flush entirely — do not crash.
   - Perform the flush ONLY after the target is ready to commit: fresh disk loads after staging succeeds, AND cache-hit switches when `reload_from_disk=False`. Do NOT flush before a disk load succeeds.
   - Resolve the previous document's story editor widget EXPLICITLY before committing new state. Do NOT rely on `focus_get()`: when `open_file()` is invoked from a dock/list click, focus can be on a read-only widget such as `txt_opened_files` or `txt_results`, which makes `_commit_widget_edit()` silently no-op. Resolution order:
       * if `is_box0_active` -> `txt_box0_summary`
       * elif continuous view and `current_box_idx` in `_card_widgets` -> that card's `txt`
       * elif plain-text fallback in continuous view -> `txt_continuous`
       * else -> `txt_dialogue`
   - Guard each with `winfo_exists()`, then call `_commit_widget_edit(that_widget)`.
   - If the flush raises, report through the existing logger/error dialog and return WITHOUT committing any new state.
   - Preserve existing explicit `reload_from_disk=True` semantics. If a reload from disk fails, keep the previous in-memory document and editor buffer intact.
   - Do not invent a new commit architecture.

C. Commit State Together Only After Success
   - Only after staging succeeds, commit all active document fields together:
     `current_file_path`, `current_doc`, `current_unity_env`, `current_text_obj`, `is_bundle_file`, `current_box_idx`, `is_box0_active`, `is_dirty`, `_modified_boxes`, `_original_box_texts`, `_locked_boxes`, `_plain_text_content`, plus `last_opened_dir`, window title, `recent_files`, `open_documents`, and UI views/status.
   - Preserve the existing `open_documents` cache architecture and cache-hit behavior.
   - Do NOT change how `_original_box_texts` is populated on cache-hit in this slice; the UID-keyed Japanese source registry is owned by a later slice.

D. Complete Preservation on Any Failure
   - If loading or parsing fails for any reason, leave previous `current_file_path`, `current_doc`, `current_unity_env`, `current_text_obj`, `is_bundle_file`, `is_dirty`, `_locked_boxes`, `_modified_boxes`, `_original_box_texts`, `_plain_text_content`, `current_box_idx`, `is_box0_active`, visible editor buffer, window title, `recent_files`, `last_opened_dir`, and `open_documents` completely unchanged.
   - Do not create or overwrite any `open_documents` entry for the failed file.
   - When `reload_from_disk=True` fails for the CURRENT path, the already-existing `open_documents[path]` entry must remain intact (neither deleted nor overwritten).
   - Report the error through existing logger and error dialog mechanisms; keep the app usable.

==================================================
REQUIRED REGRESSION TESTS (FAILING-FIRST)
==================================================
Create `tests/test_s1_open_file_safety.py` using the existing `unittest` architecture. Do not introduce a new testing framework.

Clean TDD order (no git commands needed):
  1. Write the tests below.
  2. Run them against the UNPATCHED code and record the actual output.
  3. Implement S1.
  4. Re-run and record the actual output.

Per-test expectation (do not "fix" a test that is already correct):
  - Tests 1, 2, 3, 5, 6 MUST FAIL before S1 and PASS after S1.
  - Test 4 MUST PASS both before and after S1 (it is a regression guard, not a defect probe).

Mock targets (critical — wrong target will not intercept the call):
  - `load_bundle_story` is imported into the `misora` module namespace, so patch `misora.load_bundle_story`. Patching `core.bundle_io.load_bundle_story` will NOT intercept the call made inside `open_file()`.
  - For the v2 failure path use `unittest.mock.patch.object(misora.StoryDocument, "from_v2_text", side_effect=...)`. This is a runtime mock only; never edit `core/story_ast.py`.

TEST 1 — Failed Bundle Load
  - Open valid document A with non-default dirty/lock/modified/source-cache/title/recent state.
  - Attempt to open an existing `.unity3d` path B with `misora.load_bundle_story` mocked to raise.
  - Assert A remains intact across path, doc identity, Unity env/obj, dirty state, locks, modified boxes, source cache, title, `recent_files`, and `open_documents` (no entry for B).

TEST 2 — Invalid UTF-8 Real Bytes
  - Open valid document A.
  - Write real invalid UTF-8 bytes to a disk file B with a `.txt` extension, e.g. `b"hello\x80\xffworld"` (no BOM; does not start with `#!priconne-story`).
  - Attempt to open B; assert loading fails and A remains active and completely unchanged.

TEST 3 — Malformed / Failing v2 Script
  - Open a v2 file B and trigger a `StoryDocument.from_v2_text` parse failure. If the parser is permissive for crafted text, mock `from_v2_text` to raise instead of modifying core.
  - Assert loading fails and A remains active and completely unchanged.

TEST 4 — Successful Load Regression (must pass before AND after)
  - Verify normal loading still works for ordinary UTF-8 text, a valid Misora v2 script, and a valid Unity bundle when its fixture and `UnityPy` are available.

TEST 5 — Pending Edit Preservation
  - Open document A, modify the editor widget WITHOUT triggering `KeyRelease`, then successfully switch to document B. Verify BOTH a fresh-load switch and a cache-hit switch.
  - Assert A's edit was committed into A's in-memory document before switching.
  - Repeat with a failing open of invalid B; assert A's uncommitted editor buffer and state are NOT replaced or discarded.

TEST 6 — Save Target After Failed Open
  - While A is active, attempt to open invalid B (fails).
  - Verify the active save target remains A and B is never targeted or overwritten.

==================================================
OUT OF SCOPE (DO NOT IMPLEMENT)
==================================================
- Save All, `on_save()` success boolean, Close/Exit lifecycle changes (S2/S3)
- Per-file `UndoJournal` revision redesign or `_dirty_state_changed` refactor (S2/S7)
- Multi-file Replace All (S5)
- UID-based locks or UID-based Japanese source registry (S7)
- Search/MTL/Batch threading changes (S6)
- `destroy()` after-job sweep, shortcuts, ribbon, Player Name button, Watermark (S8)
- Left Sidebar Open Project, In-App Console, MTL Drawer, Import from XUAT (S9–S11)
- Module splitting or unrelated performance/UI rewrites

==================================================
FINAL VERIFICATION & DELIVERABLE
==================================================
After implementing S1, run and report actual outputs:
1. `py -3.12 -m compileall -q misora.py core assets tests`
2. `py -3.12 -m unittest tests.test_s1_open_file_safety -v` (show the BEFORE-fix failure output and the AFTER-fix pass output)
3. `py -3.12 -m unittest discover -s tests -v`
4. Inspect `git status` and `git diff` to verify: no mass EOL churn, no unrelated edits, no weakened tests, no new dependencies, no conflict markers, and no exposed config/secrets.

Deliver a concise report containing:
1. Root-cause summary
2. S0 baseline verification results
3. Files modified
4. Summary of the staged-loading implementation
5. Regression tests added (with failing-first -> passing proof, and Test 4 pass/pass)
6. Exact commands run and actual outputs
7. Known limitations or skipped tests
8. Items explicitly deferred to S2+
9. `PROJECT_STATE.md` update summary

STOP after S0 + S1 verification and wait for user review.
